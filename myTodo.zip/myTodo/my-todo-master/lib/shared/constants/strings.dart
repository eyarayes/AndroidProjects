const String onboarding = '/';
const String welcomepage = '/welcome/page';
const String loginpage = '/login_page';
const String signuppage = '/signup_page';
const String homepage = '/my_homepage';
const String addtaskpage = '/addtask_page';
