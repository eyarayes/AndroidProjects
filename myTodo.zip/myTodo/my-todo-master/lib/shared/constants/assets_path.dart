class MyAssets {
  static const String onboradingone = 'assets/images/onboardingone.png';
  static const String onboradingtwo = 'assets/images/onboardingtwo.png';
  static const String onboradingthree = 'assets/images/onboardingthree.png';
  static const String welcomesketch = 'assets/images/welcome.png';
  static const String googleicon = 'assets/icons/google.png';
  static const String facebookicon = 'assets/icons/facebook.png';
  static const String profileicon1 = 'assets/icons/profile1.png';
  static const String profileicon2 = 'assets/icons/profile2.png';
  static const String profileicon3 = 'assets/icons/profile3.png';
  static const String profileicon4 = 'assets/icons/profile4.png';
  static const String clipboard = 'assets/icons/clipboard.png';
}
